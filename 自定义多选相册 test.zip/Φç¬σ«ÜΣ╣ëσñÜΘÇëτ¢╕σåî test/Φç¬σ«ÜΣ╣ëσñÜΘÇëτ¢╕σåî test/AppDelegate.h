//
//  AppDelegate.h
//  自定义多选相册 test
//
//  Created by 蓝科 on 16/6/8.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

