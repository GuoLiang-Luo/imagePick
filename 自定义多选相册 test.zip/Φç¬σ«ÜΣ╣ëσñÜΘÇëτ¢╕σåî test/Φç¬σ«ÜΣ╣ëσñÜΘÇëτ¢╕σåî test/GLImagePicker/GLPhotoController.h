//
//  GLPhotoController.h
//  自定义多选相册.1
//
//  Created by 蓝科 on 16/6/6.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GLAlbumModel;
@class GLPhotoController;

@protocol GLPhotoControllerDelegate <NSObject>

/**
 *  获取你选择的所有图片的数组
 *
 *  @param photoController 图片选择器
 *  @param array            你选择的所有图片的数组
 */

- (void)photosController:(GLPhotoController *)photoController didFinishPickImageWithArray:(NSArray<UIImage *> *)array;

@end

@interface GLPhotoController : UIViewController

@property (nonatomic, strong) GLAlbumModel *albumModel;
@property (nonatomic, weak) id<GLPhotoControllerDelegate> delegate;

@end
