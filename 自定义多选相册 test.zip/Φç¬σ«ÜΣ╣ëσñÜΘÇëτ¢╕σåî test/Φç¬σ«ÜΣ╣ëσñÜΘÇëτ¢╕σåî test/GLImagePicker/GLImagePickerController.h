//
//  GLImagePickerController.h
//  自定义多选相册.1
//
//  Created by 蓝科 on 16/6/7.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GLImagePickerController;

@protocol GLImagePickerControllerDelegate <NSObject>

/**
 *  获取你选择的所有图片的数组
 *
 *  @param photosCountroller 图片选择器
 *  @param array             你选择的所有图片的数组
 */
- (void)imagePickerController:(GLImagePickerController*)imagePickerController didFinishPickImageWithArray:(NSArray<UIImage *> *)array;

@end

@interface GLImagePickerController : UINavigationController

@property (nonatomic, weak)id <GLImagePickerControllerDelegate> glDelegate;

@end
