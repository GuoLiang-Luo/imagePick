//
//  GLAlbumModel.m
//  自定义多选相册.1
//
//  Created by 蓝科 on 16/6/6.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import "GLAlbumModel.h"

@implementation GLAlbumModel

-(instancetype)initWithGroup:(ALAssetsGroup *)group
{
    self = [super init];
    if (self) {
        //相册名字
        self.name = [group valueForProperty:ALAssetsGroupPropertyName];
        //相片数量
        self.number = [NSString stringWithFormat:@"%ld",group.numberOfAssets];
        //相册缩略图
        self.thumbImage = [UIImage imageWithCGImage:group.posterImage];
        
        //设置资源组assetsGroup
        self.assetsGroup = group;
    }
    return self;
}

+(instancetype)albumModelWithGroup:(ALAssetsGroup *)group
{
    return [[GLAlbumModel alloc]initWithGroup:group];
}

@end
