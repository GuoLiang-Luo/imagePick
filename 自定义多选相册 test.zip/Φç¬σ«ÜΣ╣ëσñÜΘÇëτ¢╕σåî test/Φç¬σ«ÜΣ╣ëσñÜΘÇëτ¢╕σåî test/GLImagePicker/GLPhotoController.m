//
//  GLPhotoController.m
//  自定义多选相册.1
//
//  Created by 蓝科 on 16/6/6.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import "GLPhotoController.h"
#import "GLAlbumModel.h"
#import "GLPhotoModel.h"


#define kMargin 5
#define kViewW self.view.bounds.size.width
#define kViewH self.view.bounds.size.height
#define kColumn 4
#define kCellW (kViewW-kMargin*(kColumn+1))/kColumn
#define kCellH kCellW
#define kBottomH 40
#define kDoneBtnW 40
#define kDoneBtnH 20
#define kCountBtnW 22
#define kCountBtnH 22

static NSString *cellIdentifier = @"cellIdentifier";

@interface GLPhotoController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) dispatch_queue_t serialQueue;
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray *photos;
@property (nonatomic, strong) UIView *bottomView;
@property (nonatomic, strong) UIButton *doneButton;
@property (nonatomic, strong) UIButton *countButton;
@property (nonatomic, strong) NSMutableArray *originalImages;

@end

@implementation GLPhotoController

#pragma mark -- 懒加载
-(dispatch_queue_t)serialQueue
{
    if (_serialQueue == nil) {
        _serialQueue = dispatch_queue_create("serial queue", NULL);
    }
    return _serialQueue;
}
- (NSMutableArray *)originalImages
{
    if (_originalImages == nil) {
        _originalImages = [NSMutableArray array];
    }
    return _originalImages;
}

- (UIButton *)countButton
{
    if (_countButton == nil) {
        _countButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _countButton.frame = CGRectMake(CGRectGetMinX(self.doneButton.frame)-kCountBtnW, (kBottomH-kCountBtnH)*0.5, kCountBtnW, kCountBtnH);
        [_countButton setImage:[UIImage imageNamed:@"GLImagePicker.bundle/gl_badge"] forState:UIControlStateNormal];
        _countButton.titleLabel.font = [UIFont systemFontOfSize:14];
        //设置_countButton的titleLabel的位置
        _countButton.titleEdgeInsets = UIEdgeInsetsMake(0, -kCountBtnW, 0, 0);
        //计数按钮默认隐藏
        _countButton.hidden = YES;
        
    }
    return _countButton;
}

- (UIButton *)doneButton
{
    if (_doneButton == nil) {
        _doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_doneButton setTitle:@"完成" forState:UIControlStateNormal];
        [_doneButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_doneButton setTitleColor:[UIColor grayColor] forState:UIControlStateDisabled];
        [_doneButton setFrame:CGRectMake(kViewW-kDoneBtnW-10, (kBottomH-kDoneBtnH)*0.5, kDoneBtnW, kDoneBtnH)];
        [_doneButton addTarget:self action:@selector(done) forControlEvents:UIControlEventTouchUpInside];
        //默认完成按钮不可用
        [_doneButton setEnabled:NO];
    }
    return _doneButton;
}

- (UIView *)bottomView
{
    if (_bottomView == nil) {
        _bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, kViewH-kBottomH, kViewW, kBottomH)];
        _bottomView.backgroundColor = [UIColor whiteColor];
    }
    return _bottomView;
}
-(NSMutableArray *)photos
{
    if (_photos == nil) {
        _photos = [NSMutableArray array];
    }
    return _photos;
}
-(UICollectionView *)collectionView
{
    if (_collectionView == nil) {
        CGRect frame = self.view.bounds;
        frame.size.height -= kBottomH;
        _collectionView = [[UICollectionView alloc] initWithFrame:frame collectionViewLayout:[[UICollectionViewFlowLayout alloc]init]];
        _collectionView.backgroundColor = [UIColor whiteColor];
        _collectionView.allowsMultipleSelection = YES;//允许collectionView多选
        [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:cellIdentifier];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
    }
    return _collectionView;
}

#pragma mark -- 重写父类方法
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(back)];
    
    [self.view addSubview:self.collectionView];
    [self.view addSubview:self.bottomView];
    [self.bottomView addSubview:self.doneButton];
    [self.bottomView addSubview:self.countButton];
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //滚动到collectionView的底部
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:self.photos.count-1 inSection:0];
    [self.collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionBottom animated:YES];
}

-(void)setAlbumModel:(GLAlbumModel *)albumModel
{
    _albumModel = albumModel;
    
    self.title = self.albumModel.name;
    
    //从assetsGroup获取相册中对应的照片资源
    [self loadData];
}


#pragma mark -- 自定义方法
//点击完成按钮调用的方法
-(void)done
{
     [self dismissViewControllerAnimated:YES completion:nil];
    if ([self.delegate respondsToSelector:@selector(photosController:didFinishPickImageWithArray:)]) {
        [self.delegate photosController:self didFinishPickImageWithArray:self.originalImages];
    }
}

//设置选取图片数量
- (void)setCount
{
    //设置按钮是否隐藏
    if (self.originalImages.count<=0) {
        self.countButton.hidden = YES;
        //完成按钮不可用
        [self.doneButton setEnabled:NO];
    } else {
        self.countButton.hidden = NO;
        //完成按钮可用
        [self.doneButton setEnabled:YES];
    }
    //1.创建动画
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"bounds"];
    //2.设置关键帧动画的values
    NSValue *value1 = [NSValue valueWithCGRect:CGRectMake(0, 0, kCountBtnW*0.5, kCountBtnH*0.5)];
    NSValue *value2 = [NSValue valueWithCGRect:CGRectMake(0, 0, kCountBtnW*1.2, kCountBtnH*1.2)];
    NSValue *value3 = [NSValue valueWithCGRect:CGRectMake(0, 0, kCountBtnW, kCountBtnH)];
    animation.values = @[value1,value2,value3];
    //3.添加动画
    [self.countButton.imageView.layer addAnimation:animation forKey:nil];
    
    NSString *title = [NSString stringWithFormat:@"%ld",self.originalImages.count];
    [self.countButton setTitle:title forState:UIControlStateNormal];
}
//从assetsGroup获取相册中对应的照片资源
-(void)loadData
{
    //获取资源组
    ALAssetsGroup *assetsGroup = self.albumModel.assetsGroup;
    
    //从相册资源组assetsGroup遍历照片资源ALAsset
    [assetsGroup enumerateAssetsUsingBlock:^(ALAsset *result, NSUInteger index, BOOL *stop) {
        if (result) {
            GLPhotoModel *photoModel = [GLPhotoModel photoModelWithAsset:result];
            
            [self.photos addObject:photoModel];
        }else{
            //遍历结束 刷新collectionView界面
            [self.collectionView reloadData];
        }
    }];
}

-(void)back
{
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.photos.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //cell重用
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    
    //获取相应的GLPhotoModel对象
    GLPhotoModel *photoModel = self.photos[indexPath.item];
    //设置背景视图
    cell.backgroundView = [[UIImageView alloc] initWithImage:photoModel.thumbImage];
    //设置被选中后的背景视图
    cell.selectedBackgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"GLImagePicker.bundle/gl_overlay"]];
    
    return cell;
}

#pragma mark - UICollectionViewDelegate
-(void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(nonnull NSIndexPath *)indexPath//取消选定
{
    dispatch_async(self.serialQueue, ^{
        //获取返选的originalImage
        GLPhotoModel *photoModel = self.photos[indexPath.item];
        UIImage *originalImage = photoModel.originalImage;
        
        //从originalImages中将originalImage移除
        [self.originalImages removeObject:originalImage];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //设置选取图片数量
            [self setCount];
        });
    });
   
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    dispatch_async(self.serialQueue, ^{
        GLPhotoModel *photoModel = self.photos[indexPath.item];
        
        if (!photoModel.originalImage) {
            ALAsset *asset = photoModel.asset;
            //获取asset中的原始图片
            ALAssetRepresentation *representation = [asset defaultRepresentation];
            UIImage *fullScreenImage = [UIImage imageWithCGImage:representation.fullScreenImage];
            
            //给photoModel的originalImage赋值
            photoModel.originalImage = fullScreenImage;
        }
        
        //将选择的原始图片添加到originalImages可变数组中
        [self.originalImages addObject:photoModel.originalImage];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //设置选取图片数量
            [self setCount];
        });
    });
    
}

#pragma mark - UICollectionViewDelegateFlowLayout
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(kCellW, kCellH);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(kMargin, kMargin, kMargin, kMargin);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return kMargin;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return kMargin;
}

@end
