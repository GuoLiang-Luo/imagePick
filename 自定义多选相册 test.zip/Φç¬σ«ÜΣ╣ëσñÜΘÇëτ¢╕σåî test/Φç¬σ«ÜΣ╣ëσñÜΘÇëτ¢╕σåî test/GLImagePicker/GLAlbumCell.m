//
//  GLAlbumCell.m
//  自定义多选相册.1
//
//  Created by 蓝科 on 16/6/6.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import "GLAlbumCell.h"
#import "GLAlbumModel.h"

@interface GLAlbumCell ()

@property (weak, nonatomic) IBOutlet UIImageView *albumView;
@property (weak, nonatomic) IBOutlet UILabel *titleView;
@property (weak, nonatomic) IBOutlet UILabel *numberView;

@end

@implementation GLAlbumCell


+(GLAlbumCell *)albumCellWithTableView:(UITableView *)tableView
{
    static NSString *cellIdentifier = @"albumCellIdentifier";
    GLAlbumCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[NSBundle mainBundle] loadNibNamed:@"GLAlbumCell" owner:nil options:nil].firstObject;
    }
    return cell;
}

-(void)setAlbumModel:(GLAlbumModel *)albumModel
{
    _albumModel = albumModel;
    //设置cell显示内容
     [self settingData];
}
//设置cell显示内容
-(void)settingData
{
    self.albumView.image = self.albumModel.thumbImage;
    self.titleView.text = self.albumModel.name;
    self.numberView.text = [NSString stringWithFormat:@"%@张照片",self.albumModel.number];
}

+ (CGFloat)getCellHeight
{
    return 80;
}

@end
