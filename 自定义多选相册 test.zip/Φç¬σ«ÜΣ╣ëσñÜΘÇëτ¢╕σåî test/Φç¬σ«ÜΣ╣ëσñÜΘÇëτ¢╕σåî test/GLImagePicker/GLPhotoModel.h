//
//  GLPhotoModel.h
//  自定义多选相册.1
//
//  Created by 蓝科 on 16/6/6.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AssetsLibrary/AssetsLibrary.h>

@interface GLPhotoModel : NSObject

@property (nonatomic, strong) UIImage *thumbImage;
@property (nonatomic, strong) UIImage *originalImage;
@property (nonatomic, strong) ALAsset *asset;

-(instancetype)initWithAsset:(ALAsset *)asset;
+(instancetype)photoModelWithAsset:(ALAsset *)asset;

@end
