//
//  GLAlbumCell.h
//  自定义多选相册.1
//
//  Created by 蓝科 on 16/6/6.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GLAlbumModel;

@interface GLAlbumCell : UITableViewCell

@property (nonatomic, strong) GLAlbumModel *albumModel;

+ (GLAlbumCell *)albumCellWithTableView:(UITableView *)tableView;
+(CGFloat)getCellHeight;

@end
