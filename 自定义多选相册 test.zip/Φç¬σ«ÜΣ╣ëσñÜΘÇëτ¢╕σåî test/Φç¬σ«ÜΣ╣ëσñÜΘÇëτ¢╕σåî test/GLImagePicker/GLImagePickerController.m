//
//  GLImagePickerController.m
//  自定义多选相册.1
//
//  Created by 蓝科 on 16/6/7.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import "GLImagePickerController.h"
#import "GLAlbumController.h"

@interface GLImagePickerController ()<GLAlbumControllerDelegate>

@end

@implementation GLImagePickerController

-(instancetype)init
{
    GLAlbumController *albumController = [[GLAlbumController alloc] init];
    albumController.delegate = self;
    self = [super initWithRootViewController:albumController];
    
    return self;
}

#pragma mark -- GLAlbumControllerDelegate
-(void)albumController:(GLAlbumController *)albumController didFinishPickImageWithArray:(NSArray<UIImage *> *)array
{
    if ([self.glDelegate respondsToSelector:@selector(imagePickerController:didFinishPickImageWithArray:)]) {
        [self.glDelegate imagePickerController:self didFinishPickImageWithArray:array];
    }
}

@end
