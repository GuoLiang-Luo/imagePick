//
//  GLAlbumController.m
//  自定义多选相册.1
//
//  Created by 蓝科 on 16/6/6.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import "GLAlbumController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "GLAuthorTool.h"
#import "GLAlbumModel.h"
#import "GLAlbumCell.h"
#import "GLPhotoController.h"

@interface GLAlbumController ()<UITableViewDataSource,UITableViewDelegate,GLPhotoControllerDelegate>

@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic, strong) ALAssetsLibrary *assetsLibrary;//资源库对象
@property (nonatomic, strong) NSMutableArray *albums;

@end

@implementation GLAlbumController
#pragma mark - 懒加载
- (NSMutableArray *)albums
{
    if (_albums == nil) {
        _albums = [NSMutableArray array];
    }
    return _albums;
}

- (ALAssetsLibrary *)assetsLibrary
{
    if (_assetsLibrary == nil) {
        _assetsLibrary = [[ALAssetsLibrary alloc] init];
    }
    return _assetsLibrary;
}
- (UITableView *)tableView
{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}

#pragma mark -- 重写父类方法
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置navigationBar的属性
    [self setNavigationBar];
    
    [self.view addSubview:self.tableView];
    
    //从资源库中获取相应数据
    [self loadData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark -- 自定义方法
//从资源库中获取相应数据
-(void)loadData
{
    //判断客户端是否开启相册功能 如果开启直接去资源 如果没有开启则提示用户手动开启
    [GLAuthorTool authorToolAccessLibrarySuccess:^{
        
        //遍历资源库中所有资源
        [self.assetsLibrary enumerateGroupsWithTypes:ALAssetsGroupAll usingBlock:^(ALAssetsGroup *group, BOOL *stop) {
            
            //判断group存在时才获取资源
            if (group) {
                //设置group过滤器 只获取照片
                [group setAssetsFilter:[ALAssetsFilter allPhotos]];
                
                //判断group中资源的个数是否为0
                if (group.numberOfAssets>0) {
                    
                    //用group创建GLAlbumModel对象
                    GLAlbumModel *albumModel = [GLAlbumModel albumModelWithGroup:group];
                    //将albumModel添加到albums数组中
                    [self.albums addObject:albumModel];
                }
            //最后遍历出的group为空 说明遍历结束 然后刷新tableView 偷偷push到照片流界面
            }else{
                [self.tableView reloadData];
                
                //push到照片流界面
                GLPhotoController *cameraRollVC = [[GLPhotoController alloc]init];
                cameraRollVC.delegate = self;
                cameraRollVC.albumModel = self.albums.lastObject;
                [self.navigationController pushViewController:cameraRollVC animated:NO];
            }
        } failureBlock:^(NSError *error) {
            
            NSLog(@"获取组失败");
        }];
    } fail:^{
        //程序的名字
        NSDictionary *info =[[NSBundle mainBundle] infoDictionary];
        NSString *projectName =[info objectForKey:@"CFBundleName"];
        NSString *title = [NSString stringWithFormat:@"请在%@的“设置－隐私－照片”选项中，允许%@访问您的手机。",[UIDevice currentDevice].model,projectName];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles: nil];
        [alertView show];
        
    }];
    
}

//设置navigationBar的属性
-(void)setNavigationBar
{
    //navigationBar的背景颜色
    self.navigationController.navigationBar.barTintColor = [UIColor purpleColor];
    //navigationBar设置属性标题
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};
    self.title = @"照片";
    //navigationBar设置右侧取消按钮
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(back)];
    //navigationBar上按钮的颜色
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
}

-(void)back
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.albums.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    GLAlbumCell *cell = [GLAlbumCell albumCellWithTableView:tableView];
    GLAlbumModel *albumModel = self.albums[indexPath.row];
    cell.albumModel = albumModel;
    
    return cell;
}


#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [GLAlbumCell getCellHeight];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    GLPhotoController *photoController = [[GLPhotoController alloc] init];
    photoController.albumModel = self.albums[indexPath.row];
    photoController.delegate = self;
    
    [self.navigationController pushViewController:photoController animated:YES];
}

#pragma mark -- GLPhotoControllerDelegate
-(void)photosController:(GLPhotoController *)photoController didFinishPickImageWithArray:(NSArray<UIImage *> *)array
{
    if ([self.delegate respondsToSelector:@selector(albumController:didFinishPickImageWithArray:)]) {
        [self.delegate albumController:self didFinishPickImageWithArray:array];
    }
}


@end
