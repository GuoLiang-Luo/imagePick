//
//  GLAlbumController.h
//  自定义多选相册.1
//
//  Created by 蓝科 on 16/6/6.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GLAlbumController;

@protocol GLAlbumControllerDelegate <NSObject>

/**
 *  获取你选择的所有图片的数组
 *
 *  @param albumController 图片选择器
 *  @param array             你选择的所有图片的数组
 */
- (void)albumController:(GLAlbumController*)albumController didFinishPickImageWithArray:(NSArray<UIImage *> *)array;

@end

@interface GLAlbumController : UIViewController

@property (nonatomic, weak) id<GLAlbumControllerDelegate> delegate;

@end
