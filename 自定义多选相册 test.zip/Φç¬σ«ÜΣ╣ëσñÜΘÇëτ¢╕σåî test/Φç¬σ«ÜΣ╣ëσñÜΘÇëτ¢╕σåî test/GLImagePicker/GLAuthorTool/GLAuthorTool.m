//
//  GLAuthorTool.m
//  相机和相册 1
//
//  Created by 蓝科 on 16/4/21.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import "GLAuthorTool.h"
#import <UIKit/UIKit.h>
#import <Photos/Photos.h>
#import <AssetsLibrary/AssetsLibrary.h>

@implementation GLAuthorTool

+(void)authorToolAccessCameraSuccess:(BlockType)successBlock fail:(BlockType)failBlock
{
    //判断有没有相机功能
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        //判断相机权限是否打开
        //获取相机的权限状态
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (status == AVAuthorizationStatusDenied ||
            status == AVAuthorizationStatusRestricted) {
            //执行失败的block
            failBlock();
        }else{
            //执行失败的block
            successBlock();
        }
    }else{
        NSLog(@"您的设备没有相机功能");
    }
}

+(void)authorToolAccessLibrarySuccess:(BlockType)successBlock fail:(BlockType)failBlock
{
    //判断有没有相册功能
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        //判断相机权限是否打开
        if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f) {
            //获取系统版本8.0以上相册的权限状态
            PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
            if (status == PHAuthorizationStatusDenied ||
                status == PHAuthorizationStatusRestricted) {
                //执行失败的block
                failBlock();
            }else{
                //执行成功的block
                successBlock();
            }
        }else{
            //获取系统版本4.0-9.0相册的权限状态
            ALAuthorizationStatus status = [ALAssetsLibrary authorizationStatus];
            if (status==ALAuthorizationStatusDenied||
                status==ALAuthorizationStatusRestricted) {
                //执行失败的block
                failBlock();
            } else {
                //执行成功的block
                successBlock();
            }

        }
    }

}

@end
