//
//  GLPhotoModel.m
//  自定义多选相册.1
//
//  Created by 蓝科 on 16/6/6.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import "GLPhotoModel.h"

@implementation GLPhotoModel

- (instancetype)initWithAsset:(ALAsset *)asset
{
    self = [super init];
    if (self) {
        self.thumbImage = [UIImage imageWithCGImage:asset.thumbnail];
        self.asset = asset;
    }
    return self;
}

+ (instancetype)photoModelWithAsset:(ALAsset *)asset
{
    return [[GLPhotoModel alloc] initWithAsset:asset];
}


@end
