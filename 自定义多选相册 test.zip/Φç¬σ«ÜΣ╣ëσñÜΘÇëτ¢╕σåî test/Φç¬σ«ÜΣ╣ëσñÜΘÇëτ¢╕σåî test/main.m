//
//  main.m
//  自定义多选相册 test
//
//  Created by 蓝科 on 16/6/8.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
