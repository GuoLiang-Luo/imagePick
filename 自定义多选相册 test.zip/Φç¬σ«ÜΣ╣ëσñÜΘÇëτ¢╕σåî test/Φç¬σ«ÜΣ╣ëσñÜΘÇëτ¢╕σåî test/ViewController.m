//
//  ViewController.m
//  自定义多选相册 test
//
//  Created by 蓝科 on 16/6/8.
//  Copyright © 2016年 罗国梁. All rights reserved.
//

#import "ViewController.h"
#import "GLImagePickerController.h"

@interface ViewController ()<GLImagePickerControllerDelegate>
- (IBAction)imagePicker;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    
}

- (IBAction)imagePicker {
    
    GLImagePickerController *imagePicker = [[GLImagePickerController alloc] init];
    imagePicker.glDelegate = self;
    [self presentViewController:imagePicker animated:YES completion:nil ];
}
-(void)imagePickerController:(GLImagePickerController *)imagePickerController didFinishPickImageWithArray:(NSArray<UIImage *> *)array
{
    NSLog(@"%s  %@",__func__,array);
}

@end
